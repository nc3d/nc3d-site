import React from 'react';

export interface Slide {
  url: string;
  caption: string;
  tags: string;
}

export interface BlogPost {
  id: string;
  title: string;
  date: string;
  summary: string;
  imageUrl: string;
  content: React.ReactElement;
}
