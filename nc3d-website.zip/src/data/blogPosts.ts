import React from 'react';
import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: 'city-of-possibility',
    title: 'City of Possibility: 7 Projects That Will Transform the Central City',
    date: 'June 28, 2024',
    summary: 'An 8-minute flythrough of some major projects planned for Downtown Portland',
    imageUrl: 'https://i.vimeocdn.com/video/1852445100-835c2b1897371f99c1583ff55530b135c3635905d69bf7f94017364654519998-d?mw=1000&mh=563',
    content: (
      <div style={{ padding: '56.25% 0 0 0', position: 'relative' }}>
        <iframe
          src="https://player.vimeo.com/video/1073975857?badge=0&autopause=0&player_id=0&app_id=58479"
          frameBorder="0"
          allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
          style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
          title="City of Possibility: 7 Projects That Will Transform the Central City"
        ></iframe>
      </div>
    ),
  },
];
