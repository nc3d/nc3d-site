import { Slide } from '../types';
import { imageData } from './imageData';

const IMAGE_BASE_URL = 'https://d27t2gr3rsl6s9.cloudfront.net/nc3d-images/';

export const slideshowImages: Slide[] = imageData.map((slide) => ({
  ...slide,
  url: `${IMAGE_BASE_URL}${slide.url}`,
}));
