import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { blogPosts } from '../data/blogPosts';

const BlogPostPage: React.FC = () => {
  const { postId } = useParams<{ postId: string }>();
  const post = blogPosts.find((p) => p.id === postId);

  if (!post) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl text-white">Post not found</h1>
        <Link to="/blog" className="text-lg text-gray-300 hover:underline mt-4 inline-block">
          &larr; Back to Blog
        </Link>
      </div>
    );
  }

  return (
    <article className="max-w-3xl mx-auto bg-[#606060] p-6 sm:p-8 rounded-lg shadow-xl">
      <div className="mb-8">
        <Link to="/blog" className="text-gray-300 hover:underline">
          &larr; Back to Blog
        </Link>
      </div>
      <h1 className="text-4xl font-bold text-white mb-2">{post.title}</h1>
      <p className="text-md text-gray-400 mb-6">{post.date}</p>
      
      <img 
        src={post.imageUrl} 
        alt={post.title} 
        className="rounded-lg shadow-lg w-full h-auto object-cover aspect-video mb-8"
      />

      <div className="prose prose-invert prose-lg max-w-none text-gray-300">
        {post.content}
      </div>
    </article>
  );
};

export default BlogPostPage;
