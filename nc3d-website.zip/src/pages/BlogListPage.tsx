import React from 'react';
import { Link } from 'react-router-dom';
import { blogPosts } from '../data/blogPosts';

const BlogListPage: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <h1 className="text-4xl font-bold text-white mb-8 border-b-2 border-gray-500 pb-4">
        Blog & Projects
      </h1>
      <div className="space-y-12">
        {blogPosts.map((post) => (
          <div key={post.id} className="grid md:grid-cols-3 gap-8 items-start group">
            <div className="md:col-span-1">
              <Link to={`/blog/${post.id}`}>
                <img 
                  src={post.imageUrl} 
                  alt={post.title} 
                  className="rounded-lg shadow-lg w-full h-auto object-cover aspect-video transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-gray-400 mb-1">{post.date}</p>
              <h2 className="text-2xl font-semibold text-white mb-2">
                <Link to={`/blog/${post.id}`} className="hover:text-gray-300 transition-colors duration-200">
                  {post.title}
                </Link>
              </h2>
              <p className="text-gray-300 mb-4">{post.summary}</p>
              <Link 
                to={`/blog/${post.id}`} 
                className="text-white font-semibold hover:underline"
              >
                Read More &rarr;
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlogListPage;
