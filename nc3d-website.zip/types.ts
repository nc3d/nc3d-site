// FIX: Replaced placeholder content with valid TypeScript type definitions to resolve parsing errors.
import React from 'react';

export interface Slide {
  url: string;
  caption: string;
  tags: string;
}

export interface BlogPost {
  id: string;
  title: string;
  date: string;
  summary: string;
  imageUrl: string;
  content: React.ReactElement;
}